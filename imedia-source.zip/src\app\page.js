'use client';

import React, { useState, useEffect, useRef } from 'react';
import Navbar from '@/components/Navbar';
import ServicesSection from '@/components/ServicesSection';
import ParticleScene from '@/components/ParticleScene';
import CaseStudies from '@/components/CaseStudies';
import BrandsMarquee from '@/components/BrandsMarquee';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const [activeService, setActiveService] = useState('hero');
  const [hideNavbar, setHideNavbar] = useState(false);
  const [heroHidden, setHeroHidden] = useState(false);
  const heroContentRef = useRef(null);
  const particleShiftRef = useRef({ x: 0 });

  useEffect(() => {
    if (!heroContentRef.current) return;
    const animations = [];
    const triggers = [];

    // 1. Hero Content Fade & Scale
    animations.push(gsap.to(heroContentRef.current, {
      opacity: 0,
      y: -150,
      scale: 0.9,
      ease: 'power2.inOut',
      scrollTrigger: {
        trigger: '#services-trigger',
        start: 'top bottom',
        end: 'top center',
        scrub: true,
        onEnter: () => setHeroHidden(false),
        onLeave: () => setHeroHidden(true),
        onEnterBack: () => {
          setHeroHidden(false);
          setActiveService('hero');
        },
      }
    }));

    // 2. Particle Shift Animation (Move to left stage as we approach Services)
    animations.push(gsap.to(particleShiftRef.current, {
      x: 1,
      ease: 'power2.inOut',
      scrollTrigger: {
        trigger: '#services-trigger',
        start: 'top bottom',
        end: 'bottom bottom',
        scrub: 1,
      }
    }));

    // 3. Hero Reset Logic
    triggers.push(ScrollTrigger.create({
      trigger: '#services-trigger',
      start: 'top 20%',
      onEnterBack: () => {
        setActiveService('hero');
        particleShiftRef.current.x = 0;
      },
    }));

    // 4. Robust Section Top Fallback
    triggers.push(ScrollTrigger.create({
      trigger: '#services-section',
      start: 'top bottom',
      onEnter: () => setActiveService('video'),
      onEnterBack: () => setActiveService('video'),
    }));

    // 4b. Hide navbar only while services section is in view.
    triggers.push(ScrollTrigger.create({
      trigger: '#services-section',
      start: 'top top',
      end: 'bottom top',
      onEnter: () => setHideNavbar(true),
      onLeave: () => setHideNavbar(false),
      onEnterBack: () => setHideNavbar(true),
      onLeaveBack: () => setHideNavbar(false),
    }));

    // 5. Global Top Reset
    triggers.push(ScrollTrigger.create({
      trigger: 'body',
      start: 'top top',
      onEnterBack: () => {
        setActiveService('hero');
        particleShiftRef.current.x = 0;
      }
    }));

    return () => {
      animations.forEach((animation) => animation.kill());
      triggers.forEach((trigger) => trigger.kill());
    };
  }, []);

  return (
    <main className="relative min-h-screen bg-black text-white">
      <Navbar hidden={hideNavbar} />

      {/* Background Particles Stage */}
      <div
        className={`fixed inset-0 pointer-events-none transition-all duration-700 ${activeService === 'hero' ? 'z-10' : 'z-[110]'}`}
        style={{
          clipPath: activeService === 'hero' ? 'inset(0 0 0 0)' : 'inset(0 60% 0 0)'
        }}
      >
        <ParticleScene activeService={activeService} particleShift={particleShiftRef} />
      </div>

      {/* Hero Section */}
      <section
        className={`relative z-[60] flex min-h-screen items-center px-6 pt-20 transition-all duration-1000 ease-in-out ${heroHidden ? 'pointer-events-none opacity-0 invisible' : 'opacity-100'}`}
      >
        <div ref={heroContentRef} className="w-full max-w-7xl mx-auto">
          <div className="max-w-[640px]">
          <h1
            className="luxe-display mb-8 mt-10 md:mt-16 font-semibold tracking-tight text-white leading-[0.92]"
            style={{ textShadow: '0 10px 30px rgba(0,0,0,0.5)' }}
          >
            <span className="block text-[54px] sm:text-7xl md:text-8xl whitespace-nowrap">
              <span className="hero-eye-word">EYE</span>{' '}
              <span className="hero-media-word text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-500 italic">MEDIA</span>
            </span>
          </h1>

          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-indigo-500/25 bg-indigo-500/12 text-indigo-200 text-[10px] font-medium tracking-[0.18em] uppercase mb-8">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
            </span>
            Innovation Driven Studio
          </div>

          <p
            className="max-w-[620px] text-gray-200/95 text-lg md:text-xl font-normal mb-12 leading-relaxed"
            style={{ textShadow: '0 4px 20px rgba(0,0,0,0.6)' }}
          >
            Eyemedia crafts high-fidelity digital experiences that bridge the gap between imagination and execution.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start">
            <button className="group relative px-9 py-4 bg-white text-black rounded-full font-bold text-xs tracking-[0.16em] hover:bg-indigo-50 transition-all duration-300 shadow-[0_18px_44px_rgba(255,255,255,0.18)]">
              EXPLORE OUR WORK
            </button>
            <button className="px-9 py-4 border border-white/15 bg-white/[0.02] rounded-full font-bold text-xs tracking-[0.16em] hover:bg-white/6 transition-all duration-300 shadow-[inset_0_0_0_1px_rgba(255,255,255,0.05)]">
              VIEW SERVICES
            </button>
          </div>
          </div>
        </div>
      </section>

      <div id="services-trigger" className="h-[30vh]" />

      {/* Services Section */}
      <div id="services-section" className="relative z-[70]">
        <ServicesSection onServiceChange={setActiveService} activeId={activeService} />
      </div>

      {/* NEW SECTIONS CONTENT */}
      <div className="relative z-[120] bg-black">
        <CaseStudies />
        <BrandsMarquee />
        <CTASection />
        <Footer />
      </div>
    </main>
  );
}
