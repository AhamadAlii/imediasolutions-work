'use client';

import React from 'react';
import { Search, Atom } from 'lucide-react';

const Navbar = ({ hidden = false }) => {
    return (
        <nav className={`fixed top-0 w-full z-[200] transition-all duration-500 ${hidden ? 'opacity-0 -translate-y-4 pointer-events-none' : 'opacity-100 translate-y-0'}`}>
            <div className="max-w-7xl mx-auto mt-3 px-4 sm:px-6">
                <div className="h-16 rounded-2xl border border-white/10 bg-black/55 backdrop-blur-xl shadow-[0_18px_60px_rgba(0,0,0,0.55)] px-4 sm:px-6 flex justify-between items-center">
                {/* Logo */}
                <div className="flex items-center gap-3 cursor-pointer group">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center group-hover:rotate-[18deg] transition-transform duration-500">
                        <Atom className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-semibold tracking-tight text-lg bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">EYEMEDIA</span>
                </div>

                {/* Nav Links */}
                <div className="hidden md:flex gap-10 text-[10px] font-semibold text-gray-400 uppercase tracking-[0.22em]">
                    <a href="#" className="hover:text-white transition-colors">Work</a>
                    <a href="#" className="hover:text-white transition-colors">Company</a>
                    <a href="#" className="hover:text-white transition-colors">Services</a>
                    <a href="#" className="hover:text-white transition-colors">Journal</a>
                    <a href="#" className="hover:text-white transition-colors">Contact</a>
                </div>

                {/* Actions */}
                <div className="flex gap-5 items-center">
                    <button className="hidden sm:flex items-center gap-2 text-gray-500 hover:text-white transition-colors">
                        <Search className="w-5 h-5" />
                    </button>
                    <button className="bg-white text-black text-[10px] font-bold px-6 py-2.5 rounded-full hover:bg-gray-100 transition-all active:scale-95 shadow-[0_12px_34px_rgba(255,255,255,0.16)]">
                        START YOUR PROJECT
                    </button>
                </div>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
